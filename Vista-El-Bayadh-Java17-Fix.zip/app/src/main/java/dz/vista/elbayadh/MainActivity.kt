package dz.vista.elbayadh

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.zxing.integration.android.IntentIntegrator

class MainActivity:AppCompatActivity(){
 private lateinit var db:HeritageDb; private var french=false; private lateinit var content:LinearLayout
 private val cream=Color.rgb(250,241,224); private val brown=Color.rgb(75,45,24); private val gold=Color.rgb(173,116,43)
 private val cameraPermission=registerForActivityResult(ActivityResultContracts.RequestPermission()){ if(it) cameraInfo() else toast("يلزم السماح بالكاميرا لاستخدام الاكتشاف") }
 private val locationPermission=registerForActivityResult(ActivityResultContracts.RequestPermission()){ if(it) openNearby() else toast("يمكنك استخدام البحث اليدوي دون الموقع") }
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);db=HeritageDb(this);home()}
 private fun base():LinearLayout{val root=LinearLayout(this);root.orientation=LinearLayout.VERTICAL;root.setBackgroundColor(cream);root.layoutDirection=View.LAYOUT_DIRECTION_RTL;val scroll=ScrollView(this);content=LinearLayout(this);content.orientation=LinearLayout.VERTICAL;content.setPadding(18,12,18,22);scroll.addView(content);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));return root}
 private fun label(t:String,size:Float=16f,color:Int=brown,bold:Boolean=false):TextView=TextView(this).apply{text=t;textSize=size;setTextColor(color);if(bold)setTypeface(null,Typeface.BOLD);gravity=Gravity.RIGHT;setPadding(4,8,4,8)}
 private fun button(t:String,action:()->Unit):TextView=TextView(this).apply{text=t;textSize=15f;setTextColor(Color.WHITE);gravity=Gravity.CENTER;setPadding(14,14,14,14);setBackgroundColor(gold);setOnClickListener{action()}}
 private fun add(v:View){content.addView(v,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=10})}
 private fun home(){val root=base();setContentView(root);add(label("Vista El Bayadh",30f,brown,true));add(label(if(french)"Découvrez · Explorez · Préservez" else "اكتشف .. تاريخنا وتراثنا",16f,gold,true));val lang=TextView(this).apply{text=if(french)"العربية" else "FR  |  Français";setTextColor(gold);gravity=Gravity.LEFT;setOnClickListener{french=!french;home()}};add(lang)
  val hero=TextView(this).apply{text="🏜️

ولاية البيض
بين التاريخ والجمال

دليل القصور والمعالم التراثية";textSize=24f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);setPadding(16,36,16,36);setBackgroundColor(Color.rgb(137,105,67))};add(hero)
  val search=EditText(this).apply{hint=if(french)"Rechercher un monument..." else "ابحث عن معلم أو قصر أو موقع...";textSize=16f;setSingleLine(true)};add(search);add(button(if(french)"Rechercher" else "بحث عن معلم"){showSearch(search.text.toString())})
  add(label(if(french)"Explorer le patrimoine" else "اكتشف تراث ولاية البيض",21f,brown,true))
  listOf("🏛️  المعالم التاريخية      Sites historiques","🏰  القصور القديمة      Ksour anciens","🕌  المواقع الدينية      Lieux religieux","⛰️  المواقع السياحية      Sites touristiques").forEach{add(button(it){listScreen()})}
  add(label("اكتشف بالكاميرا",22f,brown,true));add(label("وجّه كاميرا هاتفك نحو المعلم لمحاولة التعرف عليه، حتى دون وجود رمز QR. عند عدم كفاية الصورة، يقترح التطبيق البحث اليدوي أو الموقع الجغرافي."));add(button("📷  ابدأ الاكتشاف بالكاميرا"){if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)cameraInfo() else cameraPermission.launch(Manifest.permission.CAMERA)})
  add(button("🗺️  الخريطة التفاعلية / المعالم القريبة"){if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED)openNearby() else locationPermission.launch(Manifest.permission.ACCESS_FINE_LOCATION)})
  add(button("▦  مسح رمز QR عند توفره"){IntentIntegrator(this).setDesiredBarcodeFormats(IntentIntegrator.QR_CODE).setPrompt("وجّه الكاميرا نحو رمز QR الخاص بالمعلم").setBeepEnabled(false).initiateScan()})
  add(button("★  المفضلة"){favoritesScreen()});add(button("ℹ  حول التطبيق"){about()});add(label("El Bayadh — Une histoire à découvrir",14f,gold,true))
 }
 private fun listScreen(){val root=base();setContentView(root);add(label("القصور والمعالم",25f,brown,true));db.all().forEach{m->add(button("🏛️  ${m.nameAr}
${m.place}"){details(m)})};add(button("العودة للرئيسية"){home()})}
 private fun details(m:Monument){val root=base();setContentView(root);add(label(m.nameAr,26f,brown,true));add(label(m.nameFr,16f,gold,true));add(label("📍 ${m.place}"));add(label("التأريخ: ${m.date}"));add(label(m.description,17f));add(label("الصور: تُضاف الصور الفوتوغرافية الموثقة لهذا المعلم في ألبومه. لا تُستخدم صورة بديلة على أنها صورة أصلية."));add(button("★ إضافة / إزالة من المفضلة"){db.toggle(m.id);toast("تم تحديث المفضلة")});add(button("فتح الموقع أو مصدر الصور"){try{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(m.image)))}catch(_:Exception){}});add(button("العودة إلى قائمة المعالم"){listScreen()})}
 private fun showSearch(q:String){val found=db.all().filter{it.nameAr.contains(q,true)||it.nameFr.contains(q,true)||it.place.contains(q,true)};val root=base();setContentView(root);add(label("نتائج البحث",24f,brown,true));if(found.isEmpty())add(label("لا توجد نتائج. جرّب اسما آخر."));found.forEach{m->add(button(m.nameAr+" — "+m.place){details(m)})};add(button("الرئيسية"){home()})}
 private fun favoritesScreen(){val ids=db.favorites();val root=base();setContentView(root);add(label("المفضلة",24f,brown,true));db.all().filter{ids.contains(it.id)}.forEach{m->add(button(m.nameAr){details(m)})};if(ids.isEmpty())add(label("لم تضف أي معلم إلى المفضلة بعد."));add(button("الرئيسية"){home()})}
 private fun cameraInfo(){val root=base();setContentView(root);add(label("الاكتشاف بالكاميرا",24f,brown,true));add(label("هذه النسخة تجهّز مسار الكاميرا وتجربة الاكتشاف، لكن نموذج الذكاء الاصطناعي للتعرف البصري الدقيق يحتاج إلى مجموعة صور تدريب موثقة لكل قصر. لن ننسب هوية إلى معلم دون ثقة كافية."));add(button("التقاط صورة للمعلم"){val i=Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);if(i.resolveActivity(packageManager)!=null)startActivityForResult(i,77)else toast("الكاميرا غير متاحة")});add(button("البحث اليدوي عن المعلم"){listScreen()});add(button("الرئيسية"){home()})}
 private fun openNearby(){try{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("geo:0,0?q=قصور ومعالم ولاية البيض الجزائر")))}catch(_:Exception){toast("تعذر فتح تطبيق الخرائط")}}
 private fun about(){val root=base();setContentView(root);add(label("Vista El Bayadh",25f,brown,true));add(label("دليل رقمي للتعريف بتراث ولاية البيض وحفظ ذاكرته. يعمل المحتوى الأساسي محليا على الهاتف. سيتم توسيع قاعدة المعالم والصور والمراجع تدريجيا."));add(button("الرئيسية"){home()})}
 override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==IntentIntegrator.REQUEST_CODE){val r=IntentIntegrator.parseActivityResult(requestCode,resultCode,data);if(r?.contents!=null)toast("تمت قراءة الرمز: "+r.contents);return};if(requestCode==77&&resultCode==Activity.RESULT_OK)toast("تم التقاط الصورة. يلزم نموذج بصري موثق لتحديد المعلم تلقائيا.")}
 private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_LONG).show()}
}

package dz.vista.elbayadh

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Monument(val id:Int,val nameAr:String,val nameFr:String,val place:String,val date:String,val description:String,val image:String)
class HeritageDb(ctx:Context):SQLiteOpenHelper(ctx,"vista_heritage.db",null,1){
 override fun onCreate(db:SQLiteDatabase){
  db.execSQL("CREATE TABLE monuments(id INTEGER PRIMARY KEY,name_ar TEXT,name_fr TEXT,place TEXT,date TEXT,description TEXT,image TEXT,favorite INTEGER DEFAULT 0)")
  val rows=listOf(
   arrayOf("1","قصر المشرية الصغرى","Ksar de Mechria Sghira","المشرية الصغرى – ولاية البيض","1564م / 981هـ","تأسس سنة 1564م وفق الوثيقة التاريخية المتاحة. يضم أزقة وساحات ومرافق دينية واقتصادية ونظاما تقليديا لتوزيع مياه السقي.","photo_pending_mashria"),
   arrayOf("2","قصر استيتن","Ksar de Stitten","استيتن – ولاية البيض","تاريخ قديم؛ يحتاج إلى تحقيق","قصر تاريخي على السفح الجنوبي لجبل كسال. تصفه الوثائق بالطوب والحجارة وبأربعة أبواب وأزقة ومساكن متداخلة. بعض الروايات التاريخية الواردة تحتاج إلى توثيق مستقل.","photo_pending_stitten"),
   arrayOf("3","قصر بنت الخص","Ksar Bent El Khess","عين العمارة – بريزينة – ولاية البيض","تأريخ مختلف عليه في المصادر","مركب تاريخي مرتبط باسم بنت الخص. تتضمن المادة الأرشيفية روايات وتواريخ متعارضة، لذلك يعرض التطبيق هذا الاختلاف بدلا من تقديم تاريخ واحد محسوم.","https://commons.wikimedia.org/wiki/File:قصر_بنت_الخص.jpg"),
   arrayOf("4","قصر أربوات العتيق","Vieux Ksar d'Arbaouat","أربوات – ولاية البيض","حوالي القرن 16م؛ نحو 1600م","قصر مبني بالطوب والمواد المحلية، يضم أربعة أحياء تتصل بأزقة تؤدي إلى الرحبة. ارتبطت الحياة فيه بالزراعة والحرف والتجارة والتكافل الاجتماعي.","https://commons.wikimedia.org/wiki/Category:Arbaouat")
  )
  rows.forEach { r -> val v=ContentValues(); v.put("id",r[0].toInt());v.put("name_ar",r[1]);v.put("name_fr",r[2]);v.put("place",r[3]);v.put("date",r[4]);v.put("description",r[5]);v.put("image",r[6]);db.insert("monuments",null,v) }
 }
 override fun onUpgrade(db:SQLiteDatabase,o:Int,n:Int){}
 fun all():List<Monument>{ val c=readableDatabase.rawQuery("SELECT id,name_ar,name_fr,place,date,description,image FROM monuments ORDER BY id",null);val a=mutableListOf<Monument>();while(c.moveToNext())a.add(Monument(c.getInt(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6)));c.close();return a }
 fun toggle(id:Int){val c=readableDatabase.rawQuery("SELECT favorite FROM monuments WHERE id=?",arrayOf(id.toString()));var v=0;if(c.moveToFirst())v=1-c.getInt(0);c.close();val cv=ContentValues();cv.put("favorite",v);writableDatabase.update("monuments",cv,"id=?",arrayOf(id.toString()))}
 fun favorites():Set<Int>{val c=readableDatabase.rawQuery("SELECT id FROM monuments WHERE favorite=1",null);val s=mutableSetOf<Int>();while(c.moveToNext())s.add(c.getInt(0));c.close();return s}
}

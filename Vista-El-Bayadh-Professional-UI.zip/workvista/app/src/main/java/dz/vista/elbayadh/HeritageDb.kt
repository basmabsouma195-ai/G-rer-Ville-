package dz.vista.elbayadh

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Monument(val id:Int,val nameAr:String,val nameFr:String,val place:String,val date:String,val description:String,val image:String,val source:String)
class HeritageDb(ctx:Context):SQLiteOpenHelper(ctx,"vista_heritage.db",null,2){
 override fun onCreate(db:SQLiteDatabase){
  db.execSQL("CREATE TABLE monuments(id INTEGER PRIMARY KEY,name_ar TEXT,name_fr TEXT,place TEXT,date TEXT,description TEXT,image TEXT,source TEXT,favorite INTEGER DEFAULT 0)")
  seed(db)
 }
 private fun seed(db:SQLiteDatabase){
  val rows=listOf(
   arrayOf("1","قصر المشرية الصغرى","Ksar de Mechria Sghira","المشرية الصغرى – ولاية البيض","1564م / 981هـ","تأسس سنة 1564م وفق المادة التراثية المتاحة. يمتاز بموقعه فوق مرتفع صخري، وبأزقته وساحاته ونظامه التقليدي لتوزيع مياه السقي ومرافقه الدينية والاقتصادية.","https://i.postimg.cc/nrL6hP3y/CIMG0174.jpg","صورة منشورة بعنوان Petit Mecheria / Le petit Mecheria؛ يلزم مطابقة الموقع ميدانياً قبل اعتمادها كصورة موثقة للقصر"),
   arrayOf("2","قصر استيتن","Ksar de Stitten","استيتن – السفح الجنوبي لجبل كسال","تاريخ قديم؛ يحتاج إلى تحقيق","قصر تاريخي ارتبط بجبال كسال. تصفه المادة التراثية بمساحة تقارب 2.8 هكتار، وأربعة أبواب ومساكن متداخلة وأزقة. الروايات المتعلقة بتاريخ التأسيس والتدمير تُعرض باعتبارها روايات تحتاج إلى تحقيق.","https://upload.wikimedia.org/wikipedia/commons/7/7e/Lever_du_soleil_depuis_Stitten_d%27El-bayadh.jpg","Cartes du Patrimoine Culturel Algérien؛ الصورة منظر من استيتن وليست لقطة مؤكدة للقصر"),
   arrayOf("3","قصر بنت الخص","Ksar Bent El Khess","عين العمارة – بريزينة – ولاية البيض","تأريخ مختلف عليه في المصادر","مركب تاريخي مرتبط باسم مباركة بنت الخص. تختلف المادة المتاحة في تأريخ القصر، لذلك يحافظ التطبيق على هذا الاختلاف ولا يقدم تاريخا واحدا باعتباره محسوما.","https://commons.wikimedia.org/wiki/Special:FilePath/%D9%82%D8%B5%D8%B1_%D8%A8%D9%86%D8%AA_%D8%A7%D9%84%D8%AE%D8%B5.jpg","Wikimedia Commons – صورة لقصر بنت الخص، تصوير Ouahab radja، 21 سبتمبر 2016، CC BY-SA 4.0"),
   arrayOf("4","قصر أربوات العتيق","Vieux Ksar d'Arbaouat","أربوات – ولاية البيض","حوالي القرن 16م؛ نحو 1600م","قصر مبني بالمواد المحلية، يضم أربعة أحياء وأزقة تتصل بالرحبة. ارتبطت الحياة فيه بالزراعة والحرف والتجارة والتكافل الاجتماعي، وهو مدرج في قائمة الجرد الإضافي بقرار سنة 2016.","https://commons.wikimedia.org/wiki/Special:FilePath/Arbaouat_%D8%A3%D8%B1%D8%A8%D9%88%D8%A7%D8%AA.jpg","Wikimedia Commons – صورة أربوات؛ تُعرض كمشهد للمنطقة وليس توثيقاً حصرياً للقصر")
  )
  rows.forEach { r -> val v=ContentValues();v.put("id",r[0].toInt());v.put("name_ar",r[1]);v.put("name_fr",r[2]);v.put("place",r[3]);v.put("date",r[4]);v.put("description",r[5]);v.put("image",r[6]);v.put("source",r[7]);db.insert("monuments",null,v) }
 }
 override fun onUpgrade(db:SQLiteDatabase,o:Int,n:Int){ if(o<2){db.execSQL("ALTER TABLE monuments ADD COLUMN source TEXT DEFAULT ''");db.execSQL("UPDATE monuments SET image='https://archiqoo.com/images/gallery/ksar_arbaouet.jpg' WHERE id=4")} }
 fun all():List<Monument>{val c=readableDatabase.rawQuery("SELECT id,name_ar,name_fr,place,date,description,image,source FROM monuments ORDER BY id",null);val a=mutableListOf<Monument>();while(c.moveToNext())a.add(Monument(c.getInt(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6),c.getString(7)));c.close();return a}
 fun toggle(id:Int){val c=readableDatabase.rawQuery("SELECT favorite FROM monuments WHERE id=?",arrayOf(id.toString()));var v=1;if(c.moveToFirst())v=1-c.getInt(0);c.close();val cv=ContentValues();cv.put("favorite",v);writableDatabase.update("monuments",cv,"id=?",arrayOf(id.toString()))}
 fun favorites():Set<Int>{val c=readableDatabase.rawQuery("SELECT id FROM monuments WHERE favorite=1",null);val s=mutableSetOf<Int>();while(c.moveToNext())s.add(c.getInt(0));c.close();return s}
}

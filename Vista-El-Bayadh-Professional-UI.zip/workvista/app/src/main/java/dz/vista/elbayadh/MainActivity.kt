package dz.vista.elbayadh

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.google.zxing.integration.android.IntentIntegrator

class MainActivity : AppCompatActivity() {
    private lateinit var db: HeritageDb
    private lateinit var page: LinearLayout
    private lateinit var root: LinearLayout
    private var french = false
    private val cream = Color.rgb(248, 244, 235)
    private val paper = Color.rgb(255, 253, 248)
    private val ink = Color.rgb(42, 48, 39)
    private val green = Color.rgb(48, 69, 54)
    private val gold = Color.rgb(178, 135, 69)
    private val muted = Color.rgb(126, 119, 103)
    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) cameraScreen() else toast("يلزم السماح بالكاميرا لاستخدام الماسح")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = green
        window.navigationBarColor = Color.rgb(34, 43, 35)
        db = HeritageDb(this)
        home()
    }

    private fun makeRoot(): LinearLayout {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(cream) }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(18, 14, 18, 22) }
        scroll.addView(page)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bottomBar(), LinearLayout.LayoutParams(-1, dp(68)))
        return root
    }

    private fun bottomBar(): LinearLayout {
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setBackgroundColor(paper); elevation = 14f; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        val items = listOf(
            Triple("⌂", if (french) "Accueil" else "الرئيسية") { home() },
            Triple("⌕", if (french) "Explorer" else "اكتشف") { explore() },
            Triple("◎", if (french) "Scanner" else "الماسح") { requestCamera() },
            Triple("♡", if (french) "Favoris" else "المفضلة") { favoritesScreen() },
            Triple("⌖", if (french) "Carte" else "الخريطة") { openNearby() }
        )
        items.forEachIndexed { index, item ->
            val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(2, 5, 2, 3); setOnClickListener { item.third() } }
            cell.addView(TextView(this).apply { text = item.first; textSize = 25f; gravity = Gravity.CENTER; setTextColor(if (index == 0) gold else green); typeface = Typeface.DEFAULT_BOLD })
            cell.addView(TextView(this).apply { text = item.second; textSize = 10f; gravity = Gravity.CENTER; setTextColor(if (index == 0) gold else muted); setTypeface(null, if (index == 0) Typeface.BOLD else Typeface.NORMAL) })
            bar.addView(cell, LinearLayout.LayoutParams(0, -1, 1f))
        }
        return bar
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun add(v: View, bottom: Int = 14) { page.addView(v, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(bottom) }) }
    private fun text(value: String, size: Float = 16f, color: Int = ink, bold: Boolean = false, align: Int = Gravity.RIGHT): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); gravity = align; if (bold) setTypeface(null, Typeface.BOLD)
        setPadding(dp(2), dp(5), dp(2), dp(5)); setLineSpacing(dp(3).toFloat(), 1.04f)
    }
    private fun title(value: String) = text(value, 21f, ink, true)
    private fun image(url: String, height: Int): ImageView = ImageView(this).apply {
        layoutParams = LinearLayout.LayoutParams(-1, dp(height)); scaleType = ImageView.ScaleType.CENTER_CROP
        setBackgroundColor(Color.rgb(220, 211, 192))
        if (url.isNotBlank()) Glide.with(this@MainActivity).load(url).diskCacheStrategy(com.bumptech.glide.load.engine.DiskCacheStrategy.ALL).centerCrop().into(this)
    }
    private fun button(label: String, action: () -> Unit): TextView = TextView(this).apply {
        text = label; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(dp(16), dp(12), dp(16), dp(12))
        setBackgroundColor(green); setOnClickListener { action() }
    }
    private fun header() {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        row.addView(TextView(this).apply { text = "VISTA\nEL BAYADH"; textSize = 22f; setTextColor(gold); typeface = Typeface.create("serif", Typeface.BOLD); letterSpacing = .08f }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(TextView(this).apply { text = if (french) "عربي" else "FR"; textSize = 13f; setTextColor(green); setPadding(dp(12), dp(8), dp(12), dp(8)); setOnClickListener { french = !french; home() } })
        add(row, 7)
    }

    private fun home() {
        setContentView(makeRoot()); header()
        add(text(if (french) "LE PATRIMOINE AU BOUT DES DOIGTS" else "اكتشف روح المكان .. واحكِ حكاية التراث", 12f, muted, true), 12)
        val hero = FrameLayout(this).apply { background = android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR, intArrayOf(green, Color.rgb(83, 94, 70))).apply { cornerRadius = dp(18).toFloat() } }
        val heroContent = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(22), dp(20), dp(22)) }
        heroContent.addView(text(if (french) "EL BAYADH" else "ولاية البيّض", 30f, Color.WHITE, true))
        heroContent.addView(text(if (french) "Une histoire à découvrir" else "ذاكرة من حجر .. وعمارة تحكي قروناً", 17f, Color.rgb(244, 225, 188), true))
        heroContent.addView(text(if (french) "Explorez les ksour, les sites et les récits" else "رحلة بين القصور والمعالم والروايات التاريخية", 13f, Color.WHITE))
        hero.addView(heroContent); add(hero, 16)
        val search = EditText(this).apply { hint = if (french) "Rechercher un lieu, un ksar…" else "ابحث عن قصر أو معلم أو منطقة"; textSize = 14f; isSingleLine = true; setPadding(dp(15), dp(12), dp(15), dp(12)); setBackgroundColor(paper) }
        add(search, 7); add(button(if (french) "RECHERCHER" else "ابحث في التراث  ←") { showSearch(search.text.toString()) }, 18)
        add(title(if (french) "À LA DÉCOUVERTE DU PATRIMOINE" else "وجهات تستحق الاكتشاف"), 7)
        db.all().forEach { card(it) }
        val discovery = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(17), dp(16), dp(17), dp(16)); background = android.graphics.drawable.GradientDrawable().apply { setColor(Color.rgb(235, 228, 210)); cornerRadius = dp(16).toFloat() } }
        discovery.addView(text(if (french) "DÉCOUVERTE PAR CAMÉRA" else "اكتشف ما تراه أمامك", 19f, green, true))
        discovery.addView(text(if (french) "Scanner un QR ou lancer l’identification visuelle expérimentale." else "امسح رمز QR إن وجد، أو التقط صورة للمعلم لبدء تجربة التعرف البصري.", 13f, muted))
        discovery.addView(button(if (french) "OUVRIR LE SCANNER" else "افتح الماسح والكاميرا") { requestCamera() })
        add(discovery, 12)
        add(text("VISTA EL BAYADH  •  PATRIMOINE & MÉMOIRE", 10f, gold, true, Gravity.CENTER), 6)
    }

    private fun card(m: Monument) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = android.graphics.drawable.GradientDrawable().apply { setColor(paper); cornerRadius = dp(16).toFloat() }; clipToOutline = true; elevation = dp(2).toFloat() }
        box.addView(image(m.image, 178))
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(8), dp(14), dp(14)) }
        info.addView(text(if (french) m.nameFr else m.nameAr, 19f, ink, true))
        info.addView(text("⌖  ${m.place}", 12f, muted))
        info.addView(text(m.date, 12f, gold, true))
        info.addView(button(if (french) "DÉCOUVRIR LE SITE  →" else "اكتشف المعلم  ←") { details(m) })
        box.addView(info); add(box, 16)
    }

    private fun explore() { setContentView(makeRoot()); add(title(if (french) "Explorer" else "استكشف المعالم")); db.all().forEach { card(it) } }
    private fun details(m: Monument) {
        setContentView(makeRoot()); add(image(m.image, 245), 12); add(title(if (french) m.nameFr else m.nameAr), 2)
        add(text(m.nameFr, 14f, gold, true), 3); add(text("⌖  ${m.place}", 13f, muted), 5)
        add(text(if (french) "REPÈRES HISTORIQUES" else "لمحة تاريخية", 12f, gold, true), 2)
        add(text(m.description, 16f), 10); add(text(if (french) "SOURCE DOCUMENTAIRE ET PHOTOGRAPHIQUE" else "المصدر التاريخي والفوتوغرافي", 12f, gold, true), 2)
        add(text(m.source, 12f, muted), 8); add(button(if (french) "AJOUTER AUX FAVORIS ♡" else "أضف إلى المفضلة  ♡") { db.toggle(m.id); toast("تم تحديث المفضلة") })
    }
    private fun showSearch(q: String) { setContentView(makeRoot()); add(title(if (french) "Résultats" else "نتائج البحث")); db.all().filter { it.nameAr.contains(q, true) || it.nameFr.contains(q, true) || it.place.contains(q, true) }.forEach { card(it) } }
    private fun favoritesScreen() { setContentView(makeRoot()); add(title(if (french) "Favoris" else "المفضلة")); val ids = db.favorites(); val found = db.all().filter { ids.contains(it.id) }; if (found.isEmpty()) add(text(if (french) "Aucun favori pour le moment" else "لم تضف أي معلم إلى المفضلة بعد", 14f, muted)); found.forEach { card(it) } }

    private fun requestCamera() { if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) cameraScreen() else cameraPermission.launch(Manifest.permission.CAMERA) }
    private fun cameraScreen() {
        setContentView(makeRoot()); add(title(if (french) "Scanner & reconnaître" else "الماسح والتعرّف على المعالم"))
        add(text(if (french) "Choisissez le mode de découverte" else "اختر طريقة التعرف على المعلم", 14f, muted))
        add(button(if (french) "SCANNER UN CODE QR" else "مسح رمز QR") { IntentIntegrator(this).setDesiredBarcodeFormats(IntentIntegrator.QR_CODE).setPrompt("وجّه الكاميرا نحو رمز QR").setBeepEnabled(false).initiateScan() }, 10)
        add(button(if (french) "PRENDRE UNE PHOTO DU MONUMENT" else "التقاط صورة للمعلم بالكاميرا") { val i = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE); if (i.resolveActivity(packageManager) != null) startActivityForResult(i, 77) else toast("الكاميرا غير متاحة") }, 10)
        add(text(if (french) "La reconnaissance automatique des monuments nécessite un modèle visuel entraîné sur des photographies vérifiées. Cette version ouvre la caméra mais ne prétend pas identifier un site sans modèle." else "ملاحظة تقنية: فتح الكاميرا والتقاط الصورة متاحان. أما تحديد اسم القصر تلقائياً فيتطلب نموذج ذكاء بصري مدرّباً على صور موثقة لكل معلم. لن نعرض اسماً تخمينياً على أنه نتيجة مؤكدة.", 13f, muted))
        add(title(if (french) "Identifier manuellement" else "أو اختر المعلم يدوياً"), 8); db.all().forEach { card(it) }
    }
    private fun openNearby() { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=قصور ومعالم ولاية البيض الجزائر"))) } catch (_: Exception) { toast("تعذر فتح تطبيق الخرائط") } }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == IntentIntegrator.REQUEST_CODE) { val r = IntentIntegrator.parseActivityResult(requestCode, resultCode, data); if (r?.contents != null) toast("تمت قراءة الرمز: ${r.contents}"); return }
        if (requestCode == 77 && resultCode == Activity.RESULT_OK) toast("تم التقاط الصورة. يلزم نموذج بصري مدرّب لتحديد المعلم تلقائياً.")
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}

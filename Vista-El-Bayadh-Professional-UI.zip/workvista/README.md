# Vista El Bayadh — Visual Edition

A fresh Android project for a bilingual heritage guide to Wilaya d'El Bayadh.

## UI direction
- Premium ivory / sand / olive / antique-gold palette.
- Persistent five-item bottom navigation: Home, Explore, Scanner, Favorites, Map.
- Image-led monument cards and dedicated detail pages.
- Arabic-first RTL layout with French toggle.

## Current features
- Local SQLite records for four documented sites: Ksar Mechria Sghira, Stitten, Bent El Khess, and old Arbaouat.
- Search and local favorites.
- QR scanning using ZXing.
- Camera permission and capture flow; **automatic monument recognition is not implemented yet** and must not be represented as functional AI recognition.
- Map intent to open a maps app.
- Glide disk caching for downloaded photos after first online load.

## Photo provenance
- Ksar Bent El Khess: Wikimedia Commons file `قصر بنت الخص.jpg`, photographer Ouahab radja, 21 Sep 2016, CC BY-SA 4.0. Source page: https://commons.wikimedia.org/wiki/File:%D9%82%D8%B5%D8%B1_%D8%A8%D9%86%D8%AA_%D8%A7%D9%84%D8%AE%D8%B5.jpg
- Arbaouat: Archiqoo image `ksar_arbaouet.jpg`, source: https://archiqoo.com/locations/ksar_arbaouet_ar.php
- Mechria Sghira: a web-published image labeled “Petit Mecheria”; location should be verified locally before presenting it as an authenticated image of the specific qasr. Source: https://steppe.doomby.com/pages/nos-ksours-1/le-petit-mecheria.html
- Stitten: the current image URL is a landscape view from Stitten, not a verified close-up of the qasr. Replace with an authenticated qasr photograph when one is available.

Images load from their source URLs and Glide caches them on device. This is not the same as bundling image bytes inside the APK or SQLite. First display requires internet access.

## Build
GitHub Actions workflow uses Java 17 and Gradle 8.9; run `gradle assembleDebug`.

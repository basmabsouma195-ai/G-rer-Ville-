# Asset status

- Home and navigation UI rebuilt around a persistent bottom bar.
- Monument photos are loaded from documented web sources and cached by Glide on-device after download.
- Not all four sites have a verified close-up photo in the sources found so far. Do not mislabel landscape or similar-site images as authenticated monument photographs.
- No computer-vision recognition model is included. Camera capture and QR scanning are separate functions.

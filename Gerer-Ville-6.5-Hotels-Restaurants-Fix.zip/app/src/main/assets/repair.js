/* Gérer Ville 6.4 — stable in-app routing and functional social sections. */
(function(){
  const tr=(a,f)=>typeof gvT5==='function'?gvT5(a,f):(lang==='ar'?a:f);
  const safeRender=(fn,fallback)=>{try{return fn()}catch(e){console.error('Gérer Ville section:',e);return `<section class="panel"><h3>${tr('تعذر عرض جزء من المحتوى','Impossible d’afficher ce contenu')}</h3><p>${tr('حاول الرجوع ثم إعادة فتح القسم.','Revenez en arrière puis rouvrez cette rubrique.')}</p></section>`}};
  window.go=function(p){page=p;detail=null;if(p!=='messages'&&window.GV4)GV4.activeChat=null;try{render()}catch(e){console.error(e)}window.scrollTo(0,0)};
  window.gvOpenChat=function(id,name,kind='friend'){GV4.activeChat={id:String(id),name:String(name),kind};page='messages';detail=null;render();window.scrollTo(0,0)};
  window.gvSendMessage=function(e,id){if(e)e.preventDefault();const input=document.getElementById('gv-msg-input');const value=(input?.value||'').trim();if(!value)return;GV4.chats[id]=Array.isArray(GV4.chats[id])?GV4.chats[id]:[];GV4.chats[id].push({from:'me',text:value,time:new Date().toLocaleTimeString(lang==='ar'?'ar-DZ':'fr-FR',{hour:'2-digit',minute:'2-digit'})});localStorage.setItem('gvChats',JSON.stringify(GV4.chats));render();const body=document.getElementById('gv-chat-body');if(body)body.scrollTop=body.scrollHeight};
  window.gvNotificationsPage=function(){const list=(window.GV5&&Array.isArray(GV5.notifications))?GV5.notifications:[];return `<div class="gv-page-title"><h2>${tr('الإشعارات','Notifications')}</h2><button class="gv-text-button" onclick="GV5.notifications.forEach(n=>n.unread=false);localStorage.setItem('gvNotifications',JSON.stringify(GV5.notifications));render()">${tr('تحديد الكل كمقروء','Tout marquer comme lu')}</button></div><div class="gv-notification-list">${list.map(n=>`<button class="gv-notification-row ${n.unread?'unread':''}" onclick="gvOpenNotification('${String(n.id).replace(/'/g,'')}')"><span class="gv-notif-icon">${n.icon||'•'}</span><span><b>${esc(n.text||'')}</b><small>${esc(n.time||'')}</small></span>${n.unread?'<i></i>':''}</button>`).join('')||`<div class="panel">${tr('لا توجد إشعارات حالياً. ستظهر هنا تفاعلاتك ورسائلك الجديدة.','Aucune notification pour le moment.')}</div>`}</div>`};
  window.gvOpenNotification=function(id){const n=(GV5.notifications||[]).find(x=>x.id===id);if(!n)return;n.unread=false;localStorage.setItem('gvNotifications',JSON.stringify(GV5.notifications));go(n.target||'home')};
  window.misc=function(){switch(page){case 'profile':return safeRender(()=>gvProfilePage());case 'friends':return safeRender(()=>gvFriendsPage());case 'messages':return safeRender(()=>gvMessagesPage());case 'notifications':return safeRender(()=>gvNotificationsPage());case 'groups':return safeRender(()=>gvGroupsPage());case 'reels':return safeRender(()=>gvReelsPage());case 'menu':return safeRender(()=>gvMenuPage());case 'settings':return safeRender(()=>gvSettingsPage());case 'saved':return safeRender(()=>{const sp=userPosts.filter(p=>saves[p.id]).map(p=>gvPostCard({...p,userPost:true})).join('');return `<div class="gv-page-title"><h2>${T('savedTitle')}</h2></div><div class="directory">${places.filter(p=>saves[p.id]).map(placeCard).join('')}</div>${sp||`<div class="panel">${tr('لا توجد عناصر محفوظة بعد.','Aucun élément enregistré.')}</div>`}`});default:return safeRender(()=>gvMenuPage())}};
  window.render=function(){const root=document.getElementById('view');if(!root)return;document.documentElement.lang=lang;document.body.classList.toggle('rtl',lang==='ar');document.body.classList.toggle('gv-dark',localStorage.gvDark==='1');safeRender(()=>{stories();nav();if(typeof gvHeader==='function')gvHeader();root.innerHTML=detail?safeRender(()=>detailPage()):page==='home'?home():['flights','hotels','food','agencies','events'].includes(page)?safeRender(()=>sectionPage(page)):misc();});};
  // Ensure the header profile shortcut always opens the profile in this same app view.
  const oldHeader=window.gvHeader;window.gvHeader=function(){if(typeof oldHeader==='function')oldHeader();const avatar=document.querySelector('.topbar .gv-header-avatar');if(avatar)avatar.onclick=()=>go('profile')};
})();

/* Gérer Ville 6.5 — targeted directory fix: hotels and restaurants only.
   Keeps the existing visual system and reuses the existing place cards/details. */
(function(){
  const gvNormalizeDirectoryType = type => {
    if (type === 'hotel' || type === 'hotels') return 'hotels';
    if (type === 'restaurant' || type === 'restaurants' || type === 'food') return 'food';
    return type;
  };
  const gvDirectoryText = value => String(value == null ? '' : value).toLocaleLowerCase();
  const gvSectionPageBeforeDirectoryFix = window.sectionPage;
  const gvUpdateSearchBeforeDirectoryFix = window.updateSearch;
  window.sectionPage = function(type){
    const normalized = gvNormalizeDirectoryType(type);
    if (normalized !== 'hotels' && normalized !== 'food') {
      return gvSectionPageBeforeDirectoryFix(type);
    }
    const all = Array.isArray(places) ? places.filter(p => gvNormalizeDirectoryType(p.type) === normalized) : [];
    const query = gvDirectoryText(window.listQuery || '').trim();
    const city = String(window.listCity || '');
    let list = all.filter(p => {
      const searchable = [p.name,p.city,p.arCity,p.kind,p.about,p.arAbout].map(gvDirectoryText).join(' ');
      const matchesQuery = !query || searchable.includes(query);
      const matchesCity = !city || p.city === city || p.arCity === city || gvDirectoryText(p.city).includes(gvDirectoryText(city));
      return matchesQuery && matchesCity;
    });
    if (window.listSort === 'rating') list.sort((a,b) => Number(b.rating || 0) - Number(a.rating || 0));
    const title = normalized === 'hotels' ? T('hotelTitle') : T('foodTitle');
    const cityOptions = [...new Map(all.map(p => [p.city,p])).keys()];
    const cards = list.map(p => placeCard(p)).join('');
    return `<div class="directoryhero"><span class="eyebrow">GÉRER VILLE · ${T('demo')}</span><h2>${title}</h2><p>${T('discover')}</p><div class="directorysearch"><span>⌕</span><input value="${esc(window.listQuery || '')}" oninput="updateSearch(this.value)" placeholder="${T('search')}"></div></div><div class="filterbar"><select onchange="window.listCity=this.value;render()"><option value="">${T('allCities')}</option>${cityOptions.map(c=>`<option value="${esc(c)}" ${city===c?'selected':''}>${esc(c)}</option>`).join('')}</select><select onchange="window.listSort=this.value;render()"><option value="recent" ${window.listSort!=='rating'?'selected':''}>${T('recent')}</option><option value="rating" ${window.listSort==='rating'?'selected':''}>★ ${T('popular')}</option></select></div><div class="directorycount">${list.length} ${lang==='ar'?'نتيجة':'résultats'}</div><div class="directory">${cards || `<div class="empty">⌕<p>${T('noResults')}</p></div>`}</div>`;
  };
  window.updateSearch = function(value){
    window.listQuery = value;
    if (page === 'hotels' || page === 'hotel' || page === 'food' || page === 'restaurant' || page === 'restaurants') {
      render();
      const input = document.querySelector('.directorysearch input');
      if (input) { input.focus(); input.setSelectionRange(value.length,value.length); }
      return;
    }
    if (typeof gvUpdateSearchBeforeDirectoryFix === 'function') gvUpdateSearchBeforeDirectoryFix(value);
  };
})();

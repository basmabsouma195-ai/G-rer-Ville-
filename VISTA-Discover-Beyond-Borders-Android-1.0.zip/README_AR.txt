VISTA — DISCOVER BEYOND BORDERS
نسخة Android WebView للعرض التفاعلي | 1.0

هذه النسخة مبنية على هيكل مشروع Android السابق الذي يستخدم GitHub Actions لبناء APK.
تم الإبقاء على الملف التالي كما هو دون أي تعديل:
.github/workflows/android.yml

طريقة البناء:
1) ارفع محتويات هذا المجلد إلى مستودع GitHub (مع إظهار المجلد المخفي .github).
2) افتح Actions.
3) شغّل Build Gérer Ville APK يدوياً أو ادفع التغييرات إلى main.
4) بعد نجاح المهمة، حمّل Artifact باسم Gerer-Ville-Complete-APK.
   ملاحظة: اسم المهمة واسم الـ Artifact بقيا كما في ملف yml الأصلي للمحافظة على التوافق.

الهوية والوظائف في النسخة:
- VISTA منصة اكتشاف سياحي قابلة للتوسع، وليست محصورة في ولاية البيض.
- التركيز الاستعراضي الحالي على ولاية البيض باعتبارها الفصل الأول.
- واجهة عربية / فرنسية / إنجليزية.
- الرئيسية، دليل الوجهات، البحث، التصنيفات، الخريطة، مسارات مقترحة، المحفوظات.
- صفحات تفاصيل لكل موقع، مع الموقع والتصنيف والوصف والإرشادات والمصادر.
- واجهة VISTA Lens كتصور بصري للواقع المعزز، وليست تعرفاً فعلياً بالمعالم.
- حفظ الأماكن محلياً في المتصفح / WebView.

مصادر المحتوى الثقافي:
1) خريطة التراث الثقافي الجزائري — ولاية البيض:
https://cartes.patrimoineculturelalgerien.org/ar/wilaya/32
2) بطاقة قور بنت الخص — مديرية الثقافة لولاية البيض:
https://cartes.patrimoineculturelalgerien.org/ar/lieu/32-el-bayadh/1404
3) وزارة الثقافة والفنون الجزائرية — قائمة الممتلكات الثقافية المحمية (ولاية البيض):
https://www.m-culture.gov.dz/index.php/fr/liste-des-biens-culturels
4) وكالة الأنباء الجزائرية — المسجد العتيق بقصر بوسمغون، 14 مارس 2026:
https://www.aps.dz/culture/patrimoine/mmqc7fkd
5) الأوقاف الجزائرية — مسجد قصر بوسمغون العتيق:
https://waqf-dz.org/

الصور الفوتوغرافية:
الصور مرتبطة بملفات Wikimedia Commons عبر Special:FilePath، وتحتاج اتصالاً بالإنترنت.
- GOUR de Bent El-Khass.jpg — صورة للقور / بريزينة:
  https://commons.wikimedia.org/wiki/File:GOUR_de_Bent_El-Khass.jpg
- Boussemghoune.jpg — صورة مرتبطة ببوسمغون:
  https://commons.wikimedia.org/wiki/File:Boussemghoune.jpg
- BREZINA 1.jpg — صورة من بريزينة:
  https://commons.wikimedia.org/wiki/File:BREZINA_1.jpg
- Tazina 1.jpg — نقش صخري من منطقة البيض، تصوير Michel-georges bernard:
  https://commons.wikimedia.org/wiki/File:Tazina_1.jpg
راجع صفحة كل ملف قبل أي نشر تجاري؛ الترخيص وبيانات المؤلف تُحدد من صفحة الملف نفسها. لا تنسب صورة إلى معلم محدد إذا لم يكن الملف يوثق ذلك المعلم مباشرة.

حدود الدقة:
- أوصاف المواقع مستندة إلى المصادر المذكورة، مع تجنب اختلاق تواريخ غير موثقة.
- إحداثيات بعض المواقع ومسارات الوصول لم تُثبت ميدانياً؛ لذلك الخريطة عامة وروابط الخرائط بحثية وليست ملاحة دقيقة.
- بيانات الطقس المباشر، التعرف الآلي بالصور، AR الفعلي، الدليل الصوتي المسجل، التقييمات الحقيقية والعمل دون إنترنت ليست مفعلة في هذه النسخة.
- واجهة AR شاشة توضيحية فقط.
- صور Wikimedia تُحمّل عند الاتصال بالإنترنت وقد تتغير روابط التحميل أو شروط الاستخدام.

معلومات البناء:
- Android applicationId: com.vista.discoverbeyondborders
- minSdk: 23
- targetSdk: 28
- compileSdk: 35
- versionName: 1.0
- واجهة WebView محلية داخل app/src/main/assets/index.html

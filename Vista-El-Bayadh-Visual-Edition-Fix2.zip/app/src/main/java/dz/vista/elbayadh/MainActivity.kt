package dz.vista.elbayadh

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.google.zxing.integration.android.IntentIntegrator

class MainActivity:AppCompatActivity(){
 private lateinit var db:HeritageDb; private var french=false; private lateinit var content:LinearLayout
 private val cream=Color.rgb(248,241,228); private val ink=Color.rgb(55,39,27); private val gold=Color.rgb(164,111,43); private val muted=Color.rgb(128,105,79)
 private val cameraPermission=registerForActivityResult(ActivityResultContracts.RequestPermission()){if(it)cameraInfo()else toast("يلزم السماح بالكاميرا لاستخدام الاكتشاف")}
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);window.statusBarColor=Color.rgb(39,69,91);window.navigationBarColor=ink;db=HeritageDb(this);home()}
 private fun base():LinearLayout{val root=LinearLayout(this);root.orientation=LinearLayout.VERTICAL;root.setBackgroundColor(cream);root.layoutDirection=View.LAYOUT_DIRECTION_RTL;val scroll=ScrollView(this);content=LinearLayout(this);content.orientation=LinearLayout.VERTICAL;content.setPadding(16,14,16,28);scroll.addView(content);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));return root}
 private fun label(t:String,size:Float=16f,color:Int=ink,bold:Boolean=false):TextView=TextView(this).apply{text=t;textSize=size;setTextColor(color);if(bold)setTypeface(null,Typeface.BOLD);gravity=Gravity.RIGHT;setPadding(3,6,3,6);setLineSpacing(2f,1.05f)}
 private fun add(v:View,bottom:Int=12){content.addView(v,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=bottom})}
 private fun pill(t:String,action:()->Unit):TextView=TextView(this).apply{text=t;textSize=14f;setTextColor(Color.WHITE);gravity=Gravity.CENTER;setPadding(18,13,18,13);setBackgroundColor(gold);setOnClickListener{action()}}
 private fun image(url:String,height:Int=190):ImageView=ImageView(this).apply{layoutParams=LinearLayout.LayoutParams(-1,height);scaleType=ImageView.ScaleType.CENTER_CROP;setBackgroundColor(Color.rgb(220,205,181));if(url.startsWith("http"))Glide.with(this@MainActivity).load(url).centerCrop().into(this)}
 private fun section(t:String){add(label(t,21f,ink,true),7)}
 private fun home(){setContentView(base())
  val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
  val brand=TextView(this).apply{text="VISTA\nEL BAYADH";textSize=25f;setTextColor(gold);setTypeface(null,Typeface.BOLD);letterSpacing=.06f;gravity=Gravity.CENTER_VERTICAL}
  top.addView(brand,LinearLayout.LayoutParams(0,-2,1f));top.addView(TextView(this).apply{text=if(french)"عربي" else "FR  |  Français";textSize=14f;setTextColor(gold);setPadding(14,10,14,10);setOnClickListener{french=!french;home()} });add(top,4)
  add(label(if(french)"DÉCOUVREZ · EXPLOREZ · PRÉSERVEZ" else "اكتشف .. تاريخنا وتراثنا",13f,muted,true),10)
  val hero=FrameLayout(this);hero.addView(image("https://archiqoo.com/images/gallery/ksar_arbaouet.jpg",245));val shade=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.BOTTOM;setPadding(18,18,18,20);setBackgroundColor(0x55000000)};shade.addView(label(if(french)"El Bayadh, mémoire de pierre" else "ولاية البيض .. ذاكرة من حجر",24f,Color.WHITE,true));shade.addView(label(if(french)"Un patrimoine à découvrir" else "قصور تحكي حكاية المكان والإنسان",15f,Color.WHITE));hero.addView(shade,FrameLayout.LayoutParams(-1,-1));add(hero,15)
  val search=EditText(this).apply{hint=if(french)"Rechercher un ksar ou un site..." else "ابحث عن قصر أو معلم أو موقع...";textSize=15f;isSingleLine=true;setPadding(16,12,16,12);setBackgroundColor(Color.WHITE)};add(search,6);add(pill(if(french)"Rechercher" else "بحث عن معلم"){showSearch(search.text.toString())},16)
  section(if(french)"Explorer le patrimoine" else "اكتشف تراث ولاية البيض")
  db.all().forEach{m->monumentCard(m)}
  section(if(french)"Découverte intelligente" else "اكتشف المعلم بطريقتك")
  val scan=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,18);setBackgroundColor(Color.rgb(237,222,198))}
  scan.addView(label(if(french)"اكتشف بالكاميرا / Découvrir par caméra" else "اكتشف بالكاميرا",21f,ink,true));scan.addView(label(if(french)"Visez le monument. Le mode caméra est expérimental et ne garantit pas encore l’identification automatique." else "وجّه كاميرا هاتفك نحو القصر. وضع التعرف البصري تجريبي؛ لا يدّعي تحديد هوية المعلم آلياً قبل توفير نموذج مدرّب وصور مرجعية كافية.",14f,muted));scan.addView(pill(if(french)"Ouvrir la caméra" else "افتح الكاميرا وجرّب الماسح"){if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)cameraInfo()else cameraPermission.launch(Manifest.permission.CAMERA)});add(scan,12)
  add(pill(if(french)"Scanner un code QR" else "مسح رمز QR عند توفره"){IntentIntegrator(this).setDesiredBarcodeFormats(IntentIntegrator.QR_CODE).setPrompt("وجّه الكاميرا نحو رمز QR").setBeepEnabled(false).initiateScan()},10)
  add(pill(if(french)"Carte des sites" else "الخريطة التفاعلية والمعالم القريبة"){openNearby()},10)
  add(pill(if(french)"Favoris" else "المفضلة ★"){favoritesScreen()},10)
  add(label("El Bayadh — Une histoire à découvrir",14f,gold,true),4)
 }
 private fun monumentCard(m:Monument){val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.WHITE);elevation=3f};card.addView(image(m.image,178));val text=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(14,8,14,14)};text.addView(label(if(french)m.nameFr else m.nameAr,19f,ink,true));text.addView(label("⌖ ${m.place}",13f,muted));text.addView(label(m.date,12f,gold,true));text.addView(pill(if(french)"Découvrir le monument" else "اكتشف المعلم ←"){details(m)});card.addView(text);add(card,15)}
 private fun details(m:Monument){setContentView(base());add(image(m.image,250),12);add(label(m.nameAr,25f,ink,true));add(label(m.nameFr,15f,gold,true));add(label("⌖ ${m.place}",14f,muted));add(label("التأريخ / Datation: ${m.date}",14f,gold,true));add(label(m.description,17f));add(label("مصدر الصورة: ${m.source}",12f,muted));add(label("ملاحظة: تُحمّل الصور من مصادرها عند توفر الإنترنت، ثم يحتفظ Glide بنسخة مخبأة على الجهاز. أول عرض للصورة يحتاج اتصالاً.",12f,muted));add(pill("★ إضافة / إزالة من المفضلة"){db.toggle(m.id);toast("تم تحديث المفضلة")});add(pill("فتح الموقع على الخريطة"){openNearby()});add(pill("العودة للرئيسية"){home()})}
 private fun showSearch(q:String){setContentView(base());add(label("نتائج البحث",23f,ink,true));val found=db.all().filter{it.nameAr.contains(q,true)||it.nameFr.contains(q,true)||it.place.contains(q,true)};if(found.isEmpty())add(label("لا توجد نتائج مطابقة"));found.forEach{monumentCard(it)};add(pill("الرئيسية"){home()})}
 private fun favoritesScreen(){setContentView(base());add(label("المفضلة",24f,ink,true));val ids=db.favorites();val found=db.all().filter{ids.contains(it.id)};if(found.isEmpty())add(label("لم تضف أي معلم بعد"));found.forEach{monumentCard(it)};add(pill("الرئيسية"){home()})}
 private fun cameraInfo(){setContentView(base());add(label("الاكتشاف بالكاميرا",24f,ink,true));add(label("هذه تجربة أولية لفتح كاميرا الهاتف والتقاط صورة للمعلم. التعرف الآلي على اسم القصر يحتاج إلى نموذج رؤية حاسوبية مدرّب على صور موثقة لكل موقع؛ لذلك لن نعرض نتيجة وهمية.",16f));add(pill("التقاط صورة للمعلم"){val i=Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);if(i.resolveActivity(packageManager)!=null)startActivityForResult(i,77)else toast("الكاميرا غير متاحة")});add(pill("اختيار المعلم يدوياً"){setContentView(base());db.all().forEach{monumentCard(it)}});add(pill("مسح QR"){IntentIntegrator(this).setDesiredBarcodeFormats(IntentIntegrator.QR_CODE).setPrompt("امسح رمز المعلم").initiateScan()});add(pill("الرئيسية"){home()})}
 private fun openNearby(){try{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("geo:0,0?q=قصور ومعالم ولاية البيض الجزائر")))}catch(_:Exception){toast("تعذر فتح تطبيق الخرائط")}}
 override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==IntentIntegrator.REQUEST_CODE){val r=IntentIntegrator.parseActivityResult(requestCode,resultCode,data);if(r?.contents!=null)toast("تمت قراءة الرمز: "+r.contents);return};if(requestCode==77&&resultCode==Activity.RESULT_OK)toast("تم التقاط الصورة. هذه النسخة لا تزال تحتاج إلى نموذج بصري للتعرف التلقائي على القصر.")}
 private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_LONG).show()}
}

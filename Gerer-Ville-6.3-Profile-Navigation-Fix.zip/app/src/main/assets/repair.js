/* Gérer Ville 6.1 repair layer — keeps the existing visual design and fixes navigation/profile/directories. */
(function(){
  const tr=(ar,fr)=>lang==='ar'?ar:fr;
  const safe=(v)=>esc(v??'');
  function goProfile(){page='profile';detail=null;if(window.GV4)GV4.activeChat=null;const v=document.getElementById('view');if(v)v.innerHTML=window.gvProfilePage();else render();window.scrollTo(0,0)}
  window.openProfilePage=goProfile;
  window.go=function(p){if(p==='profile'){goProfile();return;}page=p;detail=null;if(p!=='messages'&&window.GV4)GV4.activeChat=null;render();window.scrollTo(0,0)};
  window.saveProfile=function(){
    const name=document.getElementById('profile-name')?.value.trim();
    if(!name){toast(T('name'));return;}
    profile={...profile,name,about:document.getElementById('profile-about')?.value.trim()||'',city:document.getElementById('gv-city')?.value.trim()||profile.city||'',work:document.getElementById('gv-work')?.value.trim()||profile.work||'',link:document.getElementById('gv-link')?.value.trim()||profile.link||''};
    localStorage.setItem('gvProfile',JSON.stringify(profile));render();toast(T('profileSaved'));
  };
  window.gvUploadPhoto=function(input){const file=input?.files?.[0];if(!file)return;if(!file.type.startsWith('image/')){toast(tr('اختر ملف صورة صالحاً','Choisissez une image valide'));return;}if(file.size>1800000){toast(tr('حجم الصورة يجب أن يكون أقل من 1.8 ميغابايت','Image limitée à 1,8 Mo'));return;}const reader=new FileReader();reader.onload=()=>{profile={...profile,photo:reader.result};localStorage.setItem('gvProfile',JSON.stringify(profile));render();toast(tr('تم تحديث صورة الحساب','Photo de profil mise à jour'));};reader.readAsDataURL(file)};
  window.gvProfilePage=function(){
    const posts=(userPosts||[]).length,following=Object.values(follows||{}).filter(Boolean).length;
    return `<section class="gv-profile-cover"><div class="gv-cover-tools"><span>GÉRER VILLE · PROFILE</span></div><div class="gv-profile-main"><div class="gv-big-avatar">${gvAvatar(profile.name,profile.photo)}<label for="gv-photo-file">＋</label><input id="gv-photo-file" type="file" accept="image/*" hidden onchange="gvUploadPhoto(this)"></div><div class="gv-profile-title"><h2>${safe(profile.name)}</h2><p>${safe(profile.about||tr('مرحباً بك في Gérer Ville','Bienvenue sur Gérer Ville'))}</p><small>${safe(profile.city||'')}</small></div></div></section><div class="gv-profile-stats"><div><b>${posts}</b><span>${tr('منشوراتي','Publications')}</span></div><div><b>${following}</b><span>${tr('أتابع','Abonnements')}</span></div><div><b>${Object.keys(GV4.chats||{}).length}</b><span>${tr('محادثات','Discussions')}</span></div></div><div class="panel gv-edit-panel"><h3>✎ ${tr('تعديل الملف الشخصي','Modifier le profil')}</h3><label>${T('name')}<input id="profile-name" class="field" maxlength="48" value="${safe(profile.name)}"></label><label>${T('about')}<textarea id="profile-about" class="field" maxlength="300">${safe(profile.about||'')}</textarea></label><label>${tr('المدينة','Ville')}<input id="gv-city" class="field" maxlength="70" value="${safe(profile.city||'El Bayadh, Algérie')}"></label><label>${tr('العمل أو الدراسة','Travail ou études')}<input id="gv-work" class="field" maxlength="90" value="${safe(profile.work||'')}"></label><label>${tr('الموقع الإلكتروني','Site web')}<input id="gv-link" class="field" maxlength="120" value="${safe(profile.link||'')}"></label><button class="primary" onclick="saveProfile()">${T('saveProfile')}</button></div><div class="panel"><h3>🔖 ${T('savedTitle')}</h3>${places.filter(p=>saves[p.id]).map(p=>`<button class="savedrow" onclick="openDetail('${p.id}')">${p.emoji} ${safe(p.name)}　›</button>`).join('')||`<p class="muted">${tr('لا توجد عناصر محفوظة بعد.','Aucun élément enregistré.')}</p>`}</div><div class="sectiontitle">${tr('منشوراتي','Mes publications')}</div>${userPosts.map(p=>gvPostCard({...p,userPost:true})).join('')||`<div class="panel muted">${tr('لم تنشر شيئاً بعد.','Aucune publication pour le moment.')}</div>`}`;
  };
  function directory(type){
    const isHotel=type==='hotels', title=isHotel?T('hotelTitle'):T('foodTitle');
    let list=places.filter(p=>isHotel?(p.type==='hotels'||p.type==='hotel'):(p.type==='food'||p.type==='restaurant'));
    const q=(window.listQuery||'').trim().toLowerCase(),city=window.listCity||'';
    if(q)list=list.filter(p=>[p.name,p.city,p.arCity,p.kind,p.about,p.arAbout].join(' ').toLowerCase().includes(q));
    if(city)list=list.filter(p=>(p.city||'').toLowerCase().includes(city.toLowerCase())||(p.arCity||'').includes(city));
    if(window.listSort==='rating')list.sort((a,b)=>Number(b.rating)-Number(a.rating));
    const cities=[...new Set(places.filter(p=>isHotel?p.type==='hotels':p.type==='food').map(p=>p.city))];
    return `<div class="directoryhero"><span class="eyebrow">GÉRER VILLE · ${T('demo')}</span><h2>${title}</h2><p>${T('discover')}</p><div class="directorysearch"><span>⌕</span><input value="${safe(window.listQuery||'')}" oninput="window.listQuery=this.value;gvRefreshDirectory('${type}')" placeholder="${T('search')}"></div></div><div class="filterbar"><select onchange="window.listCity=this.value;gvRefreshDirectory('${type}')"><option value="">${T('allCities')}</option>${cities.map(c=>`<option value="${safe(c)}" ${city===c?'selected':''}>${safe(c)}</option>`).join('')}</select><select onchange="window.listSort=this.value;gvRefreshDirectory('${type}')"><option value="recent">${T('recent')}</option><option value="rating" ${window.listSort==='rating'?'selected':''}>★ ${T('popular')}</option></select></div><div class="directorycount">${list.length} ${tr('نتيجة','résultats')}</div><div class="directory" id="gv-directory-results">${list.length?list.map(placeCard).join(''):`<div class="empty">⌕<p>${T('noResults')}</p></div>`}</div>`;
  }
  window.gvRefreshDirectory=function(type){const root=document.getElementById('view');if(!root)return;const html=directory(type);const parsed=new DOMParser().parseFromString(html,'text/html');['.directorycount','#gv-directory-results'].forEach(sel=>{const old=root.querySelector(sel),next=parsed.querySelector(sel);if(old&&next)old.replaceWith(next)});};
  const oldSection=window.sectionPage;
  window.sectionPage=function(type){if(type==='hotels'||type==='food')return directory(type);return oldSection(type)};
  window.render=function(){
    document.documentElement.lang=lang;document.body.classList.toggle('rtl',lang==='ar');document.body.classList.toggle('gv-dark',localStorage.gvDark==='1');
    try{stories();nav();if(typeof gvHeader==='function')gvHeader();const view=document.getElementById('view');if(!view)return;view.innerHTML=detail?detailPage():page==='home'?home():page==='profile'?gvProfilePage():['flights','hotels','food','agencies','events'].includes(page)?sectionPage(page):misc();}
    catch(err){console.error('Gérer Ville render error:',err);const view=document.getElementById('view');if(view)view.innerHTML=`<div class="panel"><h3>${tr('حدث خطأ أثناء عرض الصفحة','Erreur d’affichage')}</h3><p>${tr('ارجع للرئيسية ثم أعد المحاولة.','Retournez à l’accueil puis réessayez.')}</p></div>`;}
  };
  // Ensure the visible account photo always opens the personal profile.
  const priorHeader=window.gvHeader;
  window.gvHeader=function(){priorHeader();const avatar=document.querySelector('.topbar .gv-header-avatar');if(avatar){avatar.onclick=goProfile;avatar.setAttribute('aria-label',tr('الملف الشخصي','Profil'));}};
})();
